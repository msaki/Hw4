
local physics = require("physics");
display.setStatusBar( display.HiddenStatusBar )
physics.start();

physics.setGravity(0,0);

local Enemy = require ("Enemy");
local soundTable=require("soundTable");

local xcent = display.contentWidth/2    -- Center x point
local ycent = display.contentHeight/2   -- Center y point

display.setStatusBar( display.HiddenStatusBar )

-- Floor 1 below is located at the top of the control bar.
-- It 'kills' any bullets that hit it.
floor = display.newRect (0, display.contentHeight-60, display.contentWidth, 5);
floor:setFillColor (1,1,1,0.0);
floor.anchorX=0;floor.anchorY=0;
physics.addBody(floor, "static");

-- Floor 2 is further below floor 1 and is intended to catch
-- other bullets that move past the control bar.
floor2 = display.newRect (0, display.contentHeight+50, display.contentWidth, 5);
floor2:setFillColor (1,1,1,1.0);
floor2.anchorX=0;floor2.anchorY=0;
physics.addBody(floor2, "static");


-- The victory function only calls after the 3 minutes of game time
-- has been completed successfuly.
-- It clears the screen and creates the congratulatory message
-- and main menu button.
function victory()
	transition.cancel( cube.shape );
      cube:removeSelf();
      cube = nil;
      HPText:removeSelf();
      scoreText:removeSelf();
      for i=1,#sq do -- Clear polygons
        transition.cancel( sq[#sq].shape );
      
       if (sq[#sq].timerRef ~= nil) then
          timer.cancel ( sq[#sq].timerRef );
       end
       if (sq[#sq].shape ~= nil) then
       	sq[#sq].shape:removeSelf();
      	sq[#sq].shape = nil;
       	sq[#sq] = nil;
       end
       
      end
      
      for i=1,#tr do -- Clear triangles
        transition.cancel( tr[#tr].shape );
      
       if (tr[#tr].timerRef ~= nil) then
          timer.cancel ( tr[#tr].timerRef );
       end
       if (tr[#tr].shape ~= nil) then
       	tr[#tr].shape:removeSelf();
      	tr[#tr].shape = nil;
       	tr[#tr] = nil;
       end
       
      end

      -- Remove the other items on screen as well as the
      -- runtime listener.
      controlBar:removeSelf();
      ceiling:removeSelf();
      timer.cancel(trit);
      timer.cancel(polyt);
      Runtime:removeEventListener("tap", fire);

   -- Create and display the congratulations message
   -- and the main menu button.
   victoryText = display.newText("You win!", 160, 160, native.systemFont, 24)
   victoryText:setFillColor(235, 235, 235)
   menublock = display.newRect(160, 200, 100, 30)
   menu = display.newText("Main Menu", 160, 200, native.systemFont, 16)
   menublock:setFillColor (0.2, 0.7, 0.6)
   menu:setFillColor (0, 0, 0)
   menu:addEventListener("tap", beginning);
end

-- Projectile 
cnt = 0;
-- The fire functions creates and shoots the player bullet forward.
function fire (event) 
  --if (cnt < 3) then
  cnt = cnt+1;
  p = display.newCircle (cube.x, cube.y-16, 5);
  p.anchorY = 1;
  p:setFillColor(0,1,0);
  physics.addBody (p, "dynamic", {radius=5} );
  p:applyForce(0, -0.4, p.x, p.y);

  audio.play( soundTable["shootSound"] );

  local function removeProjectile (event)
      if (event.phase=="began") then
      	-- Bullet contacted an object.
         event.target:removeSelf();
         event.target=nil;
         --cnt = cnt - 1;

         if (event.other.tag == "enemy") then
          -- Object in question is an enemy.
          event.other.pp:hit();
          hitcnt = hitcnt + 1;
          scoreText.text = "Hit: "..hitcnt;
          
         end
      end
    end
    -- Remove projectile.
    p:addEventListener("collision", removeProjectile);
  --end
end

-- Creates the game.
function makegame()
  ---- Main Player
  cube = display.newCircle (display.contentCenterX, display.contentHeight-100, 15);
  physics.addBody (cube, "kinematic");
  cube.HP = 5;
  cube:addEventListener("collision", userDamaged);

  -- Control bar creation.
  controlBar = display.newRect (display.contentCenterX, display.contentHeight-25, display.contentWidth, 70);
  controlBar:setFillColor(1,1,1,0.5);
  controlBar:addEventListener("touch", move);

  -- Score text.
  scoreText = display.newEmbossedText( "Hit: 0", 70, -10, native.systemFont, 40 );
  scoreText:setFillColor( 0,1,0 );

  local color = 
  {
    highlight = {0,1,1},   
    shadow = {0,1,1}  
  }
  scoreText:setEmbossColor( color );
  -- scoreText.hit and hitcnt tracks the number of times the player
  -- has hit an enemy.
  scoreText.hit = 0;
  hitcnt = 0;

  -- HP of player.
  HPText = display.newEmbossedText( "HP: 5", 240, -10, native.systemFont, 40 );
  HPText:setFillColor( 1,0,0 );

  -- Spawns polygons and triangles on a timer corresponding to 3 minutes.
  polyt = timer.performWithDelay(3000, polySpawn, 60);
  trit = timer.performWithDelay(5000, trSpawn, 36);

  -- Triggers the victory message after 3 minutes.
  victoryt = timer.performWithDelay(180000, victory);

  -- Visible ceiling that stops any projectiles that contact it.
  ceiling = display.newRect (display.contentCenterX, display.contentHeight-455, display.contentWidth, 5);
  ceiling:setFillColor (1,1,1,0.5);
  physics.addBody(ceiling, "static");

  -- Adds the runtime and clears the title screen
  -- or game over screen respectively.
  Runtime:addEventListener("tap", fire)
  if (title ~= nil) then
      title:removeSelf();
      title = nil;
      nametitle2:removeSelf();
      nametitle:removeSelf();
      startblock:removeSelf();
      start:removeSelf();
  end

  if (overText ~= nil) then
      overText:removeSelf();
      startblock:removeSelf();
      start:removeSelf();
      overText = nil;
  end
end

-- Table that holds the polygons.
sq = {}
-- Function that is called repeatedly every 3 seconds
-- to spawn another polygon.
function polySpawn()
  sq[#sq+1] = Polygon:new({xPos=math.random(30,290), yPos=50});
  sq[#sq]:spawn();
  sq[#sq]:shoot(1000);
  sq[#sq]:forward();
end

-- Table that holds the triangles.
tr = {}
-- Function that is called repeatedly every 3 seconds
-- to spawn another triangle.
function trSpawn()
  tr[#tr+1] = Triangle:new({xPos=math.random(30,290), yPos=50});
  tr[#tr]:spawn();
  tr[#tr]:trishoot(1000);
  tr[#tr]:forward();
end


function beginning() -- Generates the title screen.
	-- Clears victory message and main menu button
	-- if on the screen.
	if (menu ~= nil) then
		menu:removeSelf();
		menublock:removeSelf();
		victoryText:removeSelf();
		menu = nil;
	end
   bg = display.newImage ("sky.png"); 
   bg.x = display.contentWidth / 2;          -- Centers bg
   bg.y= display.contentHeight / 2;
   title = display.newText("Pew Pew: The Game!", 160, 100, native.systemFont, 24)
   title:setFillColor(235, 235, 235)
   nametitle = display.newText("Jared Hornbuckle", 160, 130, native.systemFont, 24)
   nametitle:setFillColor(235, 235, 235)
   nametitle2 = display.newText("Michael Saki", 160, 160, native.systemFont, 24)
   nametitle2:setFillColor(235, 235, 235)
   startblock = display.newRect(160, 200, 100, 30)
   start = display.newText("Play", 160, 200, native.systemFont, 16)
   startblock:setFillColor (0.2, 0.7, 0.6)
   start:setFillColor (0, 0, 0)
   start:addEventListener("tap", makegame);
end

beginning();
 -- Generates the title screen.

-- This function controls the movement of the player.
function move ( event )
	 if event.phase == "began" then		
		cube.markX = cube.x 
    print(cube.x)

	 elseif event.phase == "moved" then	 	
	 	local x = (event.x - event.xStart) + cube.markX	 	
	 	-- These if statements ensure the player can't
	 	-- run off the screen.
	 	if (x <= 20 + cube.width/2) then
		   cube.x = 20+cube.width/2;
		elseif (x >= display.contentWidth-20-cube.width/2) then
		   cube.x = display.contentWidth-20-cube.width/2;
		else
		   cube.x = x;		
		end

	 end
	 
end

-- This function triggers when the user contacts an enemy or
-- projectile.
function userDamaged (event) 
   cube.HP = cube.HP - 1; -- Set to 5 for insta-death. 0 for invincibility.
   HPText.text = "HP: "..cube.HP;
   if (cube.HP > 0) then 
      audio.play( soundTable["hitSound"] );  
   else 
   	-- Player death.
   	-- Clears the screen and creates the game over message
   	-- and replay button.
      audio.play( soundTable["explodeSound"] );
      timer.cancel(victoryt);
      transition.cancel( cube.shape );
      cube:removeSelf();
      cube = nil;
      HPText:removeSelf();
      scoreText:removeSelf();
      for i=1,#sq do -- Clears all active polygons.
       if (sq[#sq].shape ~= nil) then
        transition.cancel( sq[#sq].shape );
      
       		if (sq[#sq].timerRef ~= nil) then
          		timer.cancel ( sq[#sq].timerRef );
       		end
       
       	sq[#sq].shape:removeSelf();
      	sq[#sq].shape = nil;
      	sq[#sq] = nil;
       end

      end
      
       for i=1,#tr do -- Clears all active triangles.
       if (tr[#tr].shape ~= nil) then
        transition.cancel( tr[#tr].shape );
      
          if (tr[#tr].timerRef ~= nil) then
              timer.cancel ( tr[#tr].timerRef );
          end
       
        tr[#tr].shape:removeSelf();
        tr[#tr].shape = nil;
        tr[#tr] = nil;
       end

      end

      -- Clears other screen elements, runtime, and spawn timers.
      controlBar:removeSelf();
      ceiling:removeSelf();
      timer.cancel(polyt);
      timer.cancel(trit);
      Runtime:removeEventListener("tap", fire);
      overText = display.newText("Game Over", display.contentCenterX, 160, native.systemFont, 40);
      startblock = display.newRect(160, 200, 100, 30)
      start = display.newText("Re-Play", 160, 200, native.systemFont, 16)
      startblock:setFillColor (0.2, 0.7, 0.6)
      start:setFillColor (0, 0, 0)
      start:addEventListener("tap", makegame);
   end      
end

-- Polygon base values.
Polygon = Enemy:new( {HP=3, fR=0, fT=1000, bT=1000} );

-- Polygon spawn function.
function Polygon:spawn()
  local vertices = { -20,-20, -10,-40, 10,-40, 20,-20, 0,0, }

  self.shape = display.newPolygon (self.xPos, self.yPos, vertices); 

  self.shape.pp = self;
  self.shape.tag = "enemy";
  self.shape:setFillColor (255, 255, 0);
  physics.addBody(self.shape, "dynamic", {shape = vertices}); 
end

-- Move function is unused.
function Polygon:move () 
   self:forward();
end

-- Back and forward function work together to move the polygon down
-- the screen.
function Polygon:back ()   
   transition.to(self.shape, {x=self.shape.x, y = self.shape.y + 20,
           time=self.bT, rotation=self.sR, 
      onComplete=function (obj) self:forward() end});
end

function Polygon:forward () 
   transition.to(self.shape, {x=self.shape.x, y = self.shape.y + 20,
           time=self.fT, rotation=self.fR, 
      onComplete= function (obj) self:back() end });
end




------------Triangle
Triangle = Enemy:new( {HP=1, bR=0, fT=4000, bT=4000} );

-- Triangle spawn function.
function Triangle:spawn()
 self.shape = display.newPolygon(self.xPos, self.yPos, 
                      {-15,-15,15,-15,0,15});
  
 self.shape.pp = self;
 self.shape.tag = "enemy";
 self.shape:setFillColor ( 0, 0, 1);
 physics.addBody(self.shape, "dynamic", 
           {shape={-15,-15,15,-15,0,15}}); 
end

-- Back and forward function move the triangle accordingly.
function Triangle:back ()  
  transition.to(self.shape, {x=cube.x, 
    y=self.shape.y+200, time=self.bT, rotation=self.bR, 
    onComplete= function (obj) self:forward() end } );
end

function Triangle:forward ()  
  self.dist = 2 * 10;
  transition.to(self.shape, {x=cube.x,  
    y=self.shape.y+200, time=self.fT, rotation=self.fR, 
    onComplete= function (obj) self:back() end } );
end

-- Side function unused.
function Triangle:side ()  
   transition.to(self.shape, {x=self.shape.x + 20, 
      time=self.sT, rotation=self.sR, 
      onComplete= function (obj) self:back () end }); 
end



-----------






